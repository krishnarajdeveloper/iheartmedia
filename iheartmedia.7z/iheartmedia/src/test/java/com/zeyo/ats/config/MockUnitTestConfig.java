package com.zeyo.ats.config;

import static org.springframework.context.annotation.FilterType.ASSIGNABLE_TYPE;



import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.iheartmedia.service.AdvertiserService;

@EnableWebMvc
@Configuration
@ComponentScan(basePackages = {"com.iheartmedia.controller" })
public class MockUnitTestConfig extends WebMvcConfigurerAdapter {
	@Bean
	public AdvertiserService accountService() {
		AdvertiserService mock = Mockito.mock(AdvertiserService.class);
		return mock;
	}


}
