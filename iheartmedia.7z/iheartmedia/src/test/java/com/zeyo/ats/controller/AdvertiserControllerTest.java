package com.zeyo.ats.controller;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iheartmedia.controller.Advertiser;
import com.iheartmedia.service.AdvertiserService;
import com.zeyo.ats.config.MockUnitTestConfig;

/**
 * @author krish
 */

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MockUnitTestConfig.class, AnnotationConfigContextLoader.class })
public class AdvertiserControllerTest {

	@Autowired
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMVC;

	// @Mock
	// private AccountService accServiceMock;

	@Autowired
	Environment env;

	@Autowired
	@InjectMocks
	private Advertiser advertiserController;

	@Mock
	@Autowired
	private AdvertiserService accAvc;
	static ObjectMapper mapper = new ObjectMapper();

	com.iheartmedia.entities.Advertiser dummyadv;

	public AdvertiserControllerTest() {

		dummyadv = new com.iheartmedia.entities.Advertiser();
		dummyadv.setAdvertiserName("Krishna");
		dummyadv.setContactName("theja");
		dummyadv.setCreditLimit(102506);
	}

	@Before
	public void setup() throws Exception {

		MockitoAnnotations.initMocks(this);

		mockMVC = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		when(accAvc.findbyName(anyString())).thenReturn(dummyadv);
		when(accAvc.save(any(com.iheartmedia.entities.Advertiser.class))).thenReturn(dummyadv);

	}

	@Test
	public void getadvertiser_POS() throws Exception {
		try {

			MvcResult mvcResult = mockMVC
					.perform(MockMvcRequestBuilders.get("/api/advertiser/{advertiserName}", "krishna"))
					.andExpect(status().isOk()).andReturn();

			String response = mvcResult.getResponse().getContentAsString();
			assertTrue(mapper.writeValueAsString(dummyadv).equals(response));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void getadvertiser_NEG() throws Exception {
		try {

			when(accAvc.findbyName(anyString())).thenReturn(null);

			MvcResult mvcResult = mockMVC
					.perform(MockMvcRequestBuilders.get("/api/advertiser/{advertiserName}", "krishna"))
					.andExpect(status().isNotFound()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void checkLimit() throws Exception {
		try {

			MvcResult mvcResult = mockMVC
					.perform(MockMvcRequestBuilders.get("/api/advertiser/{advertiserName}/checkLimit", "krishna"))
					.andExpect(status().isOk()).andReturn();

			String response = mvcResult.getResponse().getContentAsString();
			assertTrue(("Advertiser has enough Credit to perform Transaction " + dummyadv.getCreditLimit())
					.equals(response));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void checkLimit2() throws Exception {
		try {

			dummyadv.setCreditLimit(0);
			when(accAvc.findbyName(anyString())).thenReturn(dummyadv);

			MvcResult mvcResult = mockMVC
					.perform(MockMvcRequestBuilders.get("/api/advertiser/{advertiserName}/checkLimit", "krishna"))
					.andExpect(status().isOk()).andReturn();

			String response = mvcResult.getResponse().getContentAsString();
			assertTrue(
					("Advertiser has no Credit to perform Transaction " + dummyadv.getCreditLimit()).equals(response));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void checkLimit_Neg() throws Exception {
		try {

			when(accAvc.findbyName(anyString())).thenReturn(null);

			MvcResult mvcResult = mockMVC
					.perform(MockMvcRequestBuilders.get("/api/advertiser/{advertiserName}/checkLimit", "krishna"))
					.andExpect(status().isNotFound()).andReturn();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void createAdvertiser_POS() throws Exception {
		try {

			MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.post("/api/advertiser")
					.param("advertiserName", dummyadv.getAdvertiserName())
					.param("contactName", dummyadv.getContactName()).param("creditLimit","102506"))
					.andExpect(status().isCreated()).andReturn();


			String response = mvcResult.getResponse().getContentAsString();
			assertTrue(mapper.writeValueAsString(dummyadv).equals(response));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	@Test
	public void createAdvertiser_NEG() throws Exception {
		try {

			when(accAvc.findbyName(anyString())).thenReturn(dummyadv);

			
			MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.post("/api/advertiser")
					.param("advertiserName", dummyadv.getAdvertiserName())
					.param("contactName", dummyadv.getContactName()).param("creditLimit","102506"))
					.andExpect(status().isOk()).andReturn();


			String response = mvcResult.getResponse().getContentAsString();
			assertTrue(
					("Advertiser already exist").equals(response));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
}