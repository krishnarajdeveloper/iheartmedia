package com.iheartmedia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iheartmedia.entities.Advertiser;
import com.iheartmedia.repository.AdvertiserRepository;

@Service
public class AdvertiserServiceImpl implements AdvertiserService{

	@Autowired
	AdvertiserRepository advertiserRepository;
	
	public Advertiser findbyName(String name) {
		// TODO Auto-generated method stub
		return advertiserRepository.findByName(name);
	}

	@Override
	public Advertiser save(Advertiser advertiser) {
		// TODO Auto-generated method stub
		return advertiserRepository.save(advertiser);
	}

	@Override
	public void delete(String advertiserName) {
		// TODO Auto-generated method stub
		advertiserRepository.deletebyName(advertiserName);
	}
	

}
