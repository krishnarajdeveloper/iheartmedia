package com.iheartmedia.service;

import com.iheartmedia.entities.Advertiser;

public interface AdvertiserService {

	Advertiser findbyName(String name);

	Advertiser save(Advertiser advertiser);

	void delete(String advertiserName);

}
