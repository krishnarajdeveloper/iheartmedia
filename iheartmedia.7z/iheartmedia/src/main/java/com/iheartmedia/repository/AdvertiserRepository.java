package com.iheartmedia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.iheartmedia.entities.Advertiser;

@Repository
public interface AdvertiserRepository extends JpaRepository<Advertiser, Long>{
	
    @Query("SELECT * FROM ADVERTISER WHERE name = ?1")
    Advertiser findByName(String name);

    @Query("DELETE ADVERTISER WHERE name = ?1")
	void deletebyName(String advertiserName);

}
