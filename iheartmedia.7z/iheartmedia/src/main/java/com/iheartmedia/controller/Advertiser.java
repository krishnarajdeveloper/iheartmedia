package com.iheartmedia.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.iheartmedia.configuration.ConflictException;
import com.iheartmedia.configuration.InternalServerException;
import com.iheartmedia.service.AdvertiserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javassist.NotFoundException;

import javax.servlet.http.HttpServletRequest;

//import io.swagger.annotations.Api;

@RestController
@RequestMapping("/api/advertiser")
@Api(value = "advertiserAPI", produces = MediaType.APPLICATION_JSON_VALUE)
public class Advertiser {

	@Autowired
	AdvertiserService advertiserService;

	@GetMapping("{advertiserName}")
	@ApiOperation(value = "Returns advertiser details with given advertiserName", notes = "Returns advertiser details with given advertiserName", response = com.iheartmedia.entities.Advertiser.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 500, message = "internal server error")})
	@ApiImplicitParam(name = "advertiserName", required = true, dataType = "string", paramType = "path")
	public @ResponseBody Object getAdvertiserInfo(@PathVariable String advertiserName) throws InternalServerException {
		com.iheartmedia.entities.Advertiser advertiser = null;
		try {

			advertiser = advertiserService.findbyName(advertiserName);
			if (advertiser == null)
				throw new NotFoundException("Advertiser not found for given advertiserName:" + advertiserName);

		} catch (Exception E) {
			throw new InternalServerException("Please contace Administrator");
			
		}
		return new ResponseEntity<com.iheartmedia.entities.Advertiser>(advertiser, HttpStatus.OK);

	}

	@GetMapping("{advertiserName}/checkLimit")
	@ApiOperation(value = "Returns advertiser Limit details with given advertiserName", notes = "Returns advertiser Limit details with given advertiserName", response = com.iheartmedia.entities.Advertiser.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 500, message = "internal server error")})
	@ApiImplicitParam(name = "advertiserName", required = true, dataType = "string", paramType = "path")
	public @ResponseBody Object checkLimit(@PathVariable String advertiserName) throws InternalServerException {
		com.iheartmedia.entities.Advertiser advertiser = null;
		try {

			advertiser = advertiserService.findbyName(advertiserName);
			if (advertiser == null)
				throw new NotFoundException("Advertiser not found for given advertiserName:" + advertiserName);

		} catch (Exception E) {
			throw new InternalServerException("Please contace Administrator");
		}
		if (advertiser.getCreditLimit() > 0)
			return new ResponseEntity<String>(
					"Advertiser has enough Credit to perform Transaction " + advertiser.getCreditLimit(), HttpStatus.OK);
		else
			return new ResponseEntity<String>(
					"Advertiser has no Credit to perform Transaction " + advertiser.getCreditLimit(), HttpStatus.OK);

	}

	@PostMapping
	@ApiOperation(value = "creates advertiser details with given advertiserName", notes = "creates advertiser details with given advertiserName", response = com.iheartmedia.entities.Advertiser.class)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "CREATED"),
			@ApiResponse(code = 500, message = "internal server error")})
	@ApiImplicitParams({@ApiImplicitParam(name = "advertiserName", required = true, dataType = "string", paramType = "path"),
		@ApiImplicitParam(name = "contactName", required = false, dataType = "string", paramType = "path"),	
		@ApiImplicitParam(name = "creditLimit", required = false, dataType = "int", paramType = "path")	
	})
	public @ResponseBody Object createAdvertiser(HttpServletRequest httpRequest) throws InternalServerException {
		com.iheartmedia.entities.Advertiser advertiser = null;

		try {

			advertiser = advertiserService.findbyName(httpRequest.getParameter("advertiserName"));
			if(advertiser!=null)
				throw new ConflictException("Advertiser already exist");

			changeFields(httpRequest, advertiser);
			advertiser = advertiserService.save(advertiser);


		}catch (Exception E) {
			
			throw new InternalServerException("Please contace Administrator");
		}
		return new ResponseEntity<com.iheartmedia.entities.Advertiser>(advertiser, HttpStatus.CREATED);

	}

	@PutMapping("{advertiserName}/updateAdvertiser")
	@ApiOperation(value = "updates advertiser details with given advertiserName", notes = "updates advertiser details with given advertiserName", response = com.iheartmedia.entities.Advertiser.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 500, message = "internal server error")})
	@ApiImplicitParams({@ApiImplicitParam(name = "advertiserName", required = true, dataType = "string", paramType = "path"),
		@ApiImplicitParam(name = "contactName", required = false, dataType = "string", paramType = "path"),	
		@ApiImplicitParam(name = "creditLimit", required = false, dataType = "int", paramType = "path")	
	})
	public @ResponseBody Object updateAdvertiser(@PathVariable String advertiserName, HttpServletRequest httpRequest) {
		com.iheartmedia.entities.Advertiser advertiser = null;

		try {
			advertiser = advertiserService.findbyName(advertiserName);
			changeFields(httpRequest, advertiser);
			advertiser = advertiserService.save(advertiser);

		} catch (Exception E) {
			E.printStackTrace();
		}
		return new ResponseEntity<com.iheartmedia.entities.Advertiser>(advertiser, HttpStatus.OK);

	}

	private static void changeFields(HttpServletRequest httpRequest, com.iheartmedia.entities.Advertiser advertiser)
			throws Exception {

		Map<String, String[]> paramMap = httpRequest.getParameterMap();
		Map<String, String> reqParamMap = new HashMap<String, String>();

		for (Map.Entry<String, String[]> entry : paramMap.entrySet()) {
			String key = entry.getKey();
			String[] values = entry.getValue();
			String value = null;
			if (values != null && values.length > 0)
				value = (values[0].trim() == "") ? null : values[0].trim();
			reqParamMap.put(key, value);
		}
		Set<?> set = reqParamMap.entrySet();

		Iterator<?> j = set.iterator();
		while (j.hasNext()) {
			Map.Entry me = (Map.Entry) j.next();
			advertiser.setField((String) me.getKey(), me.getValue());
		}
	}

}
