package com.iheartmedia.configuration;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@EnableAutoConfiguration
@ComponentScan
@EnableConfigurationProperties
@EnableAspectJAutoProxy
public class WebAppSpringBootInitializer extends SpringBootServletInitializer {

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    // Customize the application or call application.sources(...) to add sources
    // Since our example is itself a @Configuration class we actually don't
    // need to override this method.
    return application;
  }

  public static void main(String[] args) {
      SpringApplication.run(WebAppSpringBootInitializer.class, args);
  }

}