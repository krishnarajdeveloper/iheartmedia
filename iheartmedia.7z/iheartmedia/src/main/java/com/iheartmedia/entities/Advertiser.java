package com.iheartmedia.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Table(name = "ADVERTISER")
public class Advertiser {

	@Column
	String advertiserName;
	@Column
	String contactName;
	@Column
	int creditLimit;

	public String getAdvertiserName() {
		return advertiserName;
	}

	public void setAdvertiserName(String advertiserName) {
		this.advertiserName = advertiserName;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public int getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(int creditLimit) {
		this.creditLimit = creditLimit;
	}

	public void setField(String fieldName, Object fieldValue) throws Exception {
		
		switch (fieldName) {
		case "advertiserName":
			this.setAdvertiserName((String) fieldValue);
			break;

		case "contactName":
			this.setContactName((String) fieldValue);
			break;

		case "creditLimit":
			this.setCreditLimit(Integer.parseInt((String) fieldValue));
			break;

		}

	}
}
